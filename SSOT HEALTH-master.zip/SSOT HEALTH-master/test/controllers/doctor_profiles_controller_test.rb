require 'test_helper'

class DoctorProfilesControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
